package com.example.detoxlauncher

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    data class AppItem(val label: String, val pkg: String)

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var ticker: Runnable? = null
    private var prog: Runnable? = null
    private var apps: List<AppItem> = emptyList()
    private var screen = "home"

    private val defaultGuard = setOf(
        "com.twitter.android", "com.instagram.android", "com.google.android.youtube",
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.facebook.katana",
        "com.reddit.frontpage", "com.snapchat.android", "com.netflix.mediaclient",
        "tv.twitch.android.app"
    )

    // ---------- colors ----------
    private val dark: Boolean
        get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val bg: Int get() = if (dark) 0xFF0E100F.toInt() else 0xFFE8EBE8.toInt()
    private val ink: Int get() = if (dark) 0xFFE6EAE7.toInt() else 0xFF171A18.toInt()
    private val dim: Int get() = if (dark) 0xFF7C847F.toInt() else 0xFF7B837E.toInt()
    private val line: Int get() = if (dark) 0xFF2A2F2C.toInt() else 0xFFC9CFCA.toInt()
    private val sig: Int get() = if (dark) 0xFF7C9BFF.toInt() else 0xFF1F4FE0.toInt()
    private val sigInk: Int get() = if (dark) 0xFF0E100F.toInt() else 0xFFFFFFFF.toInt()
    private val warn: Int get() = if (dark) 0xFFFF8A80.toInt() else 0xFFB3261E.toInt()

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("detox", MODE_PRIVATE)
        rollDay()
        loadApps()
        showHome()
    }

    override fun onResume() {
        super.onResume()
        rollDay()
        loadApps()
        if (screen == "home") showHome()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        showHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen != "home") showHome()
    }

    // ---------- data ----------
    private fun rollDay() {
        val t = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (prefs.getString("day", "") != t) {
            prefs.edit().putString("day", t).putInt("opened", 0).putInt("stopped", 0).apply()
        }
    }

    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = packageManager.queryIntentActivities(i, 0)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun guards(): Set<String> = prefs.getStringSet("guard", null) ?: defaultGuard
    private fun isGuard(p: String) = guards().contains(p)
    private fun toggle(p: String) {
        val s = HashSet(guards())
        if (!s.add(p)) s.remove(p)
        prefs.edit().putStringSet("guard", s).apply()
    }

    private fun bump(key: String) {
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
    }

    private fun focusLeft(): Long = maxOf(0L, prefs.getLong("focusEnd", 0L) - System.currentTimeMillis())

    private fun fmt(ms: Long): String {
        val s = (ms + 999) / 1000
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    // ---------- ui helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: CharSequence, sp: Float, c: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = sp
            setTextColor(c)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun light(t: TextView): TextView {
        t.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        return t
    }

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(28), dp(28), dp(28), dp(20))
    }

    private fun LinearLayout.add(v: View, top: Int = 0) {
        addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) })
    }

    private fun LinearLayout.spacer() {
        addView(View(this@MainActivity), LinearLayout.LayoutParams(1, 0, 1f))
    }

    private fun shape(fill: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill)
        setStroke(dp(1), stroke)
        cornerRadius = dp(12).toFloat()
    }

    private fun btn(t: String, main: Boolean, f: () -> Unit): TextView =
        tv(t, 16f, if (main) sigInk else ink, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(16), dp(8), dp(16))
            background = shape(if (main) sig else Color.TRANSPARENT, if (main) sig else line)
            setOnClickListener { f() }
        }

    private fun row(vararg v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEachIndexed { i, x ->
            addView(x, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = dp(12)
            })
        }
    }

    private fun bar(): ProgressBar =
        ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(sig)
            progressBackgroundTintList = ColorStateList.valueOf(line)
        }

    private fun LinearLayout.addBar(pb: ProgressBar, top: Int) {
        addView(pb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(top) })
    }

    private fun setRoot(v: View) {
        window.statusBarColor = bg
        window.navigationBarColor = bg
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            if (dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        val f = FrameLayout(this)
        f.setBackgroundColor(bg)
        f.fitsSystemWindows = true
        f.addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(f)
    }

    // ---------- timers (Handler based, so they ignore animator scale) ----------
    private fun stopTimers() {
        ticker?.let { handler.removeCallbacks(it) }
        ticker = null
        cancelProgress()
    }

    private fun every(ms: Long, f: () -> Unit) {
        val r = object : Runnable {
            override fun run() {
                f()
                if (ticker === this) handler.postDelayed(this, ms)
            }
        }
        ticker = r
        handler.post(r)
    }

    private fun progress(p: ProgressBar, ms: Long, done: () -> Unit) {
        cancelProgress()
        val t0 = SystemClock.uptimeMillis()
        val r = object : Runnable {
            override fun run() {
                val fr = ((SystemClock.uptimeMillis() - t0).toFloat() / ms).coerceAtMost(1f)
                p.progress = (fr * 1000).toInt()
                if (fr >= 1f) {
                    prog = null
                    done()
                } else {
                    handler.postDelayed(this, 30)
                }
            }
        }
        prog = r
        handler.post(r)
    }

    private fun cancelProgress() {
        prog?.let { handler.removeCallbacks(it) }
        prog = null
    }

    // ---------- screens ----------
    private fun showHome() {
        stopTimers()
        screen = "home"
        val col = page()
        val clock = light(tv("", 64f, ink))
        val date = tv("", 15f, dim)
        col.add(clock, 40)
        col.add(date, 8)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val focusOn = focusLeft() > 0
        for (a in apps) {
            val g = isGuard(a.pkg)
            val lock = g && focusOn
            val sb = SpannableStringBuilder(a.label)
            if (g) {
                val s = sb.length
                sb.append("  ●")
                sb.setSpan(ForegroundColorSpan(if (lock) warn else sig), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            val t = tv(sb, 24f, if (lock) dim else ink, false).apply {
                setPadding(0, dp(9), 0, dp(9))
                if (lock) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                setOnClickListener { launch(a) }
            }
            list.addView(t)
        }
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(list)
        }
        col.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(24) })

        val stat = tv("", 13f, dim)
        val focusB = tv(if (focusOn) "集中中" else "集中", 16f, ink, true).apply {
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener { showFocus() }
        }
        val setB = tv("設定", 16f, ink, true).apply {
            setPadding(dp(14), dp(10), 0, dp(10))
            setOnClickListener { showSettings() }
        }
        val foot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(stat, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(focusB)
            addView(setB)
        }
        col.add(foot, 12)
        setRoot(col)

        every(1000) {
            val left = focusLeft()
            if ((left > 0) != focusOn) {
                showHome()
            } else {
                clock.text = SimpleDateFormat("HH:mm", Locale.US).format(Date())
                date.text = SimpleDateFormat("M月d日（E）", Locale.JAPAN).format(Date()) +
                    if (left > 0) " ・ 集中 " + fmt(left) else ""
                stat.text = "起動 ${prefs.getInt("opened", 0)} ・ 止めた ${prefs.getInt("stopped", 0)}"
            }
        }
    }

    private fun launch(a: AppItem) {
        when {
            !isGuard(a.pkg) -> openApp(a.pkg)
            focusLeft() > 0 -> showBlocked(a)
            else -> showCushion(a)
        }
    }

    private fun openApp(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        showHome()
        startActivity(i)
    }

    private fun showBlocked(a: AppItem) {
        stopTimers()
        screen = "blocked"
        val col = page()
        col.add(tv("${a.label}は今は開けません", 26f, ink, true), 40)
        col.add(tv("集中モード中です。解除までの残り時間：", 15f, dim), 8)
        val t = light(tv("", 56f, ink))
        col.add(t, 32)
        col.spacer()
        col.add(btn("ホームに戻る", true) { bump("stopped"); showHome() })
        setRoot(col)
        every(500) {
            val left = focusLeft()
            if (left <= 0) showHome() else t.text = fmt(left)
        }
    }

    private fun showCushion(a: AppItem) {
        stopTimers()
        screen = "cushion"
        val col = page()
        col.add(tv("本当にいま開く必要がありますか？", 26f, ink, true), 40)
        col.add(tv("${a.label}を開こうとしています。今日はすでに${prefs.getInt("opened", 0)}回開きました。", 15f, dim), 8)
        val pb = bar()
        col.addBar(pb, 24)
        val msg = tv("5秒待つと、次の操作が出ます。", 15f, dim)
        col.add(msg, 12)

        val go = btn("開く", true) { bump("opened"); openApp(a.pkg) }
        go.isEnabled = false
        go.alpha = 0.35f

        var next = 1
        val cells = mutableListOf<TextView>()
        fun cell(n: Int): TextView {
            val c = tv("$n", 30f, ink, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(26), 0, dp(26))
                background = shape(Color.TRANSPARENT, line)
            }
            c.setOnClickListener {
                if (next <= 4) {
                    if (n == next) {
                        c.background = shape(ink, ink)
                        c.setTextColor(bg)
                        next++
                        if (next > 4) {
                            go.isEnabled = true
                            go.alpha = 1f
                        }
                    } else {
                        next = 1
                        cells.forEach { it.background = shape(Color.TRANSPARENT, line); it.setTextColor(ink) }
                        c.background = shape(Color.TRANSPARENT, warn)
                        handler.postDelayed({ c.background = shape(Color.TRANSPARENT, line) }, 350)
                    }
                }
            }
            cells.add(c)
            return c
        }

        val nums = (1..4).shuffled()
        val pz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        pz.add(tv("1から4まで、順番にタップしてください。", 15f, dim))
        pz.add(row(cell(nums[0]), cell(nums[1])), 12)
        pz.add(row(cell(nums[2]), cell(nums[3])), 12)
        col.add(pz, 16)

        col.spacer()
        col.add(row(btn("やめる", false) { bump("stopped"); showHome() }, go), 16)
        setRoot(col)

        progress(pb, 5000) {
            msg.text = "待てました。"
            pz.visibility = View.VISIBLE
        }
    }

    private fun showFocus() {
        stopTimers()
        screen = "focus"
        val col = page()
        if (focusLeft() > 0) {
            col.add(tv("集中モード中", 26f, ink, true), 40)
            col.add(tv("対象のアプリは起動できません。残り時間：", 15f, dim), 8)
            val t = light(tv("", 56f, ink))
            col.add(t, 32)
            col.add(tv("早く終わらせたいときは、下のボタンを5秒間押し続けてください。", 15f, dim), 24)
            val pb = bar()
            col.addBar(pb, 20)
            col.spacer()
            val hold = btn("長押しで解除", false) {}
            hold.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        progress(pb, 5000) {
                            prefs.edit().putLong("focusEnd", 0L).apply()
                            showHome()
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        cancelProgress()
                        pb.progress = 0
                        true
                    }
                    else -> false
                }
            }
            col.add(row(btn("戻る", false) { showHome() }, hold), 16)
            setRoot(col)
            every(500) {
                val left = focusLeft()
                if (left <= 0) showHome() else t.text = fmt(left)
            }
            return
        }

        col.add(tv("集中する時間を決める", 26f, ink, true), 40)
        col.add(tv("この間、●の付いたアプリは起動できません。塾・勉強・移動中などに使えます。", 15f, dim), 8)
        var mins = 30
        val opts = listOf(15, 30, 60, 90, 120)
        val chips = mutableListOf<TextView>()
        fun paint() {
            chips.forEachIndexed { i, c ->
                val on = opts[i] == mins
                c.background = shape(if (on) ink else Color.TRANSPARENT, if (on) ink else line)
                c.setTextColor(if (on) bg else ink)
            }
        }
        opts.forEach { m ->
            chips.add(tv("${m}分", 16f, ink, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(12))
                setOnClickListener { mins = m; paint() }
            })
        }
        col.add(row(*chips.toTypedArray()), 24)
        paint()
        col.spacer()
        col.add(row(
            btn("戻る", false) { showHome() },
            btn("開始する", true) {
                prefs.edit().putLong("focusEnd", System.currentTimeMillis() + mins * 60000L).apply()
                showHome()
            }
        ), 16)
        setRoot(col)
    }

    private fun showSettings() {
        stopTimers()
        screen = "settings"
        val col = page()
        col.add(tv("止めるアプリを選ぶ", 26f, ink, true), 0)
        col.add(tv("●のアプリは、開く前に確認が入ります。", 15f, dim), 8)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (a in apps) {
            val st = tv("", 18f, sig, true)
            fun refresh() {
                val g = isGuard(a.pkg)
                st.text = if (g) "●" else "○"
                st.setTextColor(if (g) sig else dim)
            }
            refresh()
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(12), 0, dp(12))
                addView(tv(a.label, 19f, ink), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                addView(st)
                setOnClickListener { toggle(a.pkg); refresh() }
            }
            list.addView(r)
        }
        val sv = ScrollView(this).apply { addView(list) }
        col.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(16) })
        col.add(btn("完了", true) { showHome() }, 16)
        setRoot(col)
    }
}
