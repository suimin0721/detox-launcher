# Detox Launcher

文字だけのホーム画面、起動クッション、集中モード（タイマー中は対象アプリを起動ブロック）を備えた Android ホームランチャーです。

## APKの作り方（GitHub・かんたん）
1. 新規リポジトリを作り、このzipをそのままアップロード（Add file → Upload files）
2. Add file → Create new file で `.github/workflows/build.yml` を作り、同梱のymlを貼り付け
3. 自動でビルドされ、Releases に `detox-launcher.apk` が出ます（Actionsのログ・Artifactsにも）

## （参考）展開して使う場合
1. このフォルダの中身をGitHubリポジトリの main ブランチに push
2. Actions タブ → 「Build APK」が自動で走る（手動実行も可）
3. 完了後、Artifacts の `detox-launcher-debug-apk` をダウンロードして解凍
4. APKをスマホにインストール（提供元不明アプリの許可が必要）
5. ホームボタンを押し、「Detox Launcher」を選んで「常時」

ローカルビルド: Android Studio で開く、または `gradle assembleDebug`（Gradle 8.7+, JDK 17）。

## 仕様と制限
- ブロック・クッションの対象は「このランチャーから起動するとき」のみです。通知やリンク、他のアプリ経由の起動は止められません。
- 「止めるアプリ」は設定画面で選べます（初期値はX、Instagram、YouTube、TikTokなど）。
- 集中モードは5秒間の長押しで解除できます。
